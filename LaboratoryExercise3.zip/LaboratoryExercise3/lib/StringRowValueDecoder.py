class StringRowValueDecoder:
    """ Splits a string that contains data that is seprated by a row delimiter and a value delimiter and stores it in an array
    
    Example
    -------
    text = "hello,world;red,fox"                # setup text 
    splitter = StringRowValueDecoder(',', ';') # instantiate objecct
    print(splitter.decode(text))                 # prints [['hello','world'],['red','fox']]
    
    """
    def __init__(self, valueDeliminator, rowDeliminator):
        self.valueDeliminator = valueDeliminator
        self.rowDeliminator = rowDeliminator
        
    def decode(self, string):
        return [[cell.strip() for cell in row.split(self.valueDeliminator)] for row in string.split(self.rowDeliminator)]