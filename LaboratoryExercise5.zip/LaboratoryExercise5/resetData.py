with open("data/metadata.json", "w") as f:
    f.write("[]")