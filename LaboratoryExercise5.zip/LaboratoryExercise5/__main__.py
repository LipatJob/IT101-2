""" Please open README.md using a markdown editor to see the functionalities of the modules """

from src.Controller import Controller
def main():
    controller = Controller()
    controller.mainView()

if __name__ == "__main__":
    main()
    
    

