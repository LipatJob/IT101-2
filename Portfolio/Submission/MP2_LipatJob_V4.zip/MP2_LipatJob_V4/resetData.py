with open("data/gamestate.json", "w") as f:
    f.write("[]")
