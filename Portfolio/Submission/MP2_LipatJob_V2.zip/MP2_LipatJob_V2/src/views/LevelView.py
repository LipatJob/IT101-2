from tkinter import * 
from tkinter.font import Font
from Constants import *
from tkinter import messagebox
import random

class LevelView(Frame):
    """ The view is the UI of the application. it is recommened to use a text editor that folds code in this section"""
    def __init__(self, master=None, model = None, controller = None, **kw):
        super().__init__(master = master, **kw, bg = BG_COLOR)
        self.model = model
        self.controller = controller
        self.pics = []
        
        self.initComponents()
        self.pack(expand = True, fill = BOTH)
    
    """ INITIALIZATIONS """
    def initComponents(self):
        self.initHeader()
        self.initPicture()
        letterFrame = LettersFrame(self, self.model, onwin = self.onwin)
        letterFrame.pack()
    
    
    def initHeader(self):
        # Initialize Header
        headerFont = Font(size = "12", weight = "bold", family = "Helvetica")
        headerFrame = Frame(self, bg = HDR_COLOR)
        headerFrame.pack(fill = X, side = TOP, anchor = "n", ipady = 0, pady = (0, 25))
        
        innerPad = 20
        
        def mainMenu():
            self.controller.titleView()
        
        self.MainMenuButton = MainMenuButton(headerFrame, command = mainMenu)
        self.MainMenuButton.pack(side = LEFT, anchor = "w", padx = (innerPad, 0))
        
        self.levelFrame = LevelFrame(headerFrame, str(self.model.getLevel()))
        self.levelFrame.pack(side = LEFT, expand = True, anchor = "center")
        
        coinFrame = Frame(headerFrame, bg = HDR_COLOR, width = 100)
        coinFrame.pack(side = LEFT, anchor = "e", padx = (0, innerPad))
        
        self.coinsLabel = Label(coinFrame, text = str(self.model.getCoins()), bg = HDR_COLOR, fg = "white", font = headerFont)
        self.coinsLabel.pack(side = LEFT)
        self.coinPicture = PhotoImage(file = COIN_PICTURE)
        pictureLabel = Label(coinFrame, image = self.coinPicture,  bg = HDR_COLOR)
        pictureLabel.pack(side = LEFT)
    
        
    def initPicture(self):
         # Initialize Picture
        self.picture = PhotoImage(file = self.model.getPicture())
        pictureLabel = Label(self, image = self.picture, borderwidth = 0, relief='flat', bg = BG_COLOR)
        pictureLabel.pack(pady = (0, 20))
    
    """ ACTIONS """
    def onwin(self, skipped = False):
        if not skipped:
            self.model.increaseCoins(10)
        self.controller.nextLevel()
    
    def updateCoins(self):
        self.coinsLabel['text'] = str(self.model.getCoins())
    

    
    
class LettersFrame(Frame):
    def __init__(self, master = None, model = None, onwin = None, **kw):
        super().__init__(master = master, **kw, bg = BG_COLOR)
        self.model = model
        self.onwin = onwin
        
        self.selectionFrame = Frame(self, bg = BG_COLOR)
        self.guessFrame = Frame(self, bg = BG_COLOR)
        
        self.initSelectionFrame()
        self.initGuessFrame()
        
        self.guessFrame.pack(pady = (10, 20))
        self.selectionFrame.pack(pady = (0,0))
            
    """ INITIALIZATIONS """
    def initSelectionFrame(self):
        self.buttonFrames = []
        
        # Get word and get randomized selection of letters
        word = self.model.getWord()
        letters = self.model.createRandomSelection(word, self.model.getLevel())
        
        for index, letter in enumerate(letters):
            # Create Button Frame
            tempFrame = BlankButtonFrame(self.selectionFrame)
            tempFrame.grid(row = index // 6, column = index % 6, padx = 3, pady = 3)
            self.buttonFrames.append(tempFrame)
            
            #Create button
            button = SelectionButton(tempFrame, text = letter.upper(), origParent = tempFrame)
            button.configure(command = lambda : True)
            tempFrame.origButton = button
            button.pack()
        
        # Create Lifeline buttons
        revealFrame = Frame(self.selectionFrame, height = BTN_SIZE, width = BTN_SIZE)
        self.revealLetterButton = RevealLetterButton(revealFrame)
        self.revealLetterButton.configure(command = lambda : True)
        self.revealLetterButton.pack()
        revealFrame.grid(row = 0, column = 6, padx = 3, pady = 3)
        
        skipFrame = Frame(self.selectionFrame, height = BTN_SIZE, width = BTN_SIZE)
        self.skipLevelButton = SkipLevelButton(skipFrame)
        self.skipLevelButton.configure(command = lambda : True)
        self.skipLevelButton.pack()
        skipFrame.grid(row = 1, column = 6, padx = 3, pady = 3)
        
        
    def initGuessFrame(self):
        self.guesses = []
        word = self.model.getWord()
        
        for letter in word:
            tempFrame = BlankGuessFrame(self.guessFrame)
            tempFrame.pack(side = LEFT, padx = 3, pady = 3)
            self.guesses.append([tempFrame, None, False])
    
    

""" STYLED COMPONENTS """

class SelectionButton(Button):
    def __init__(self, master = None, origParent = None, **kw):
        self.origParent = origParent
        
        self.buttonPic = PhotoImage(file = "./assets/button.png")
        font = Font(size = 26, family = "Helvetica", weight = "bold")
        super().__init__(master=master, **kw, image = self.buttonPic, 
                         height = 60, width = 60, borderwidth = 0, highlightthickness = 0, relief='flat', 
                         bg = BG_COLOR, activebackground = BG_COLOR, activeforeground = "black" , 
                         font = font, compound="c")
        
class GuessButton(Button):
    def __init__(self, master = None, origParent = None, **kw):
        self.origParent = origParent
        
        self.guessPic = PhotoImage(file = "./assets/guess.png")
        font = Font(size = 26, family = "Helvetica", weight = "bold")
        super().__init__(master=master, **kw, image = self.guessPic, 
                         height = 50, width = 50, borderwidth = 0, highlightthickness = 0, relief='flat', 
                         bg = BG_COLOR, activebackground = BG_COLOR, fg = "white", activeforeground = "white",
                         font = font, compound="c")
        
class DeleteLetterButton(Button):
    def __init__(self, master = None, origParent = None, letter = "", **kw):
        self.origParent = origParent
        self.letter = letter
        
        self.guessPic = PhotoImage(file = "./assets/deleteLetter.png")
        font = Font(size = 26, family = "Helvetica", weight = "bold")
        super().__init__(master=master, **kw, image = self.guessPic, 
                         height = 60, width = 60, borderwidth = 0, highlightthickness = 0, relief='flat', 
                         bg = BG_COLOR, activebackground = BG_COLOR,
                         font = font, compound="c")
        
class SkipLevelButton(Button):
    def __init__(self, master = None, origParent = None, letter = "", **kw):
        self.origParent = origParent
        self.letter = letter
        
        self.guessPic = PhotoImage(file = "./assets/skip.png")
        font = Font(size = 26, family = "Helvetica", weight = "bold")
        super().__init__(master=master, **kw, image = self.guessPic, 
                         height = 60, width = 60, borderwidth = 0, highlightthickness = 0, relief='flat', 
                         bg = BG_COLOR, activebackground = BG_COLOR,
                         font = font, compound="c")
   
class BlankButtonFrame(Canvas):
    def __init__(self, master = None, origButton = None, **kw):
        super().__init__(master=master, **kw, width = 60, height = 60, 
                         borderwidth = 0, highlightthickness = 0, relief='flat', 
                         bg = BG_COLOR)
        self.origButton = origButton
        self.blankPic = PhotoImage(file = "./assets/blankbuttonframe.png")
        self.create_image(0,0, anchor = NW, image = self.blankPic)
        
class BlankGuessFrame(Canvas):
    def __init__(self, master = None, **kw):
        super().__init__(master=master, **kw, width = 50, height = 50, 
                         borderwidth = 0, highlightthickness = 0, relief='flat', 
                         bg = BG_COLOR)
        
        self.blankPic = PhotoImage(file = "./assets/guess.png")
        self.create_image(0,0, anchor = NW, image = self.blankPic)
    
class LevelFrame(Canvas):
    def __init__(self, master = None, text = "", **kw):
        super().__init__(master=master, **kw, width = 45, height = 45, 
                         borderwidth = 0, highlightthickness = 0, relief='flat', 
                         bg = HDR_COLOR)
        
        self.levelPic = PhotoImage(file = "./assets/level.png")
        self.create_image(0,0, anchor = NW, image = self.levelPic)
        levelFont = Font(size = "14", weight = "bold", family = "Helvetica")
        self.create_text(45//2, 45//2 ,text = text, anchor = "center", fill = "white", font = levelFont)
        
class MainMenuButton(Button):
    def __init__(self, master = None, origParent = None, **kw):
        self.origParent = origParent
        
        self.guessPic = PhotoImage(file = "./assets/back.png")
        font = Font(size = 26, family = "Helvetica", weight = "bold")
        super().__init__(master=master, **kw, image = self.guessPic, 
                         height = 30, width = 30, borderwidth = 0, highlightthickness = 0, relief='flat', 
                         bg = HDR_COLOR, activebackground = HDR_COLOR, fg = "white",
                         font = font, compound="c")
        
class RevealLetterButton(Button):
    def __init__(self, master = None, origParent = None, letter = "", **kw):
        self.origParent = origParent
        self.letter = letter
        
        self.guessPic = PhotoImage(file = "./assets/revealletter.png")
        font = Font(size = 26, family = "Helvetica", weight = "bold")
        super().__init__(master=master, **kw, image = self.guessPic, 
                         height = 60, width = 60, borderwidth = 0, highlightthickness = 0, relief='flat', 
                         bg = BG_COLOR, activebackground = BG_COLOR,
                         font = font, compound="c")
        
        

