import os, random
        
class LevelModel:
    """
    The Model is the intermediate class between the view and the data. The view queries the model if
    it needs a certain data.
    """
    def __init__(self, gameStateEntity = None, levelsEntity = None):
        self.gameStateEntity = gameStateEntity
        self.levelsEntity = levelsEntity
        
    def createRandomSelection(self, word, seed):
        """ Creates a random selection of words using the level as the seed"""
        falseChoices = 12 - len(word)
        alphabet = ["a", "b", "c", "d", "e", "f", "g", "h",
                    "i", "j", "k", "l", "m", "n", "o", "p",
                    "q", "r", "s", "t", "u", "v", "w", "x",
                    "y", "z"]
        wordLetters = [char for char in word.lower()]
        random.seed(seed)
        falseLetters = random.choices(alphabet, k = falseChoices)
        letterSelection = falseLetters + wordLetters
        random.seed(seed)
        random.shuffle(letterSelection)
        return letterSelection
    
    def getPicture(self):
        file = "war.png"
        return os.getcwd() + "\\assets\\pics\\resized\\" + file
    
    def getWord(self):
        return "war"
    
    def getLevel(self):
        return 1
    
    def getCoins(self):
        return 1000
    
    def getRevealed(self):
        return []
    

class LevelModelFactory():
    def create(self):
        return LevelModel()