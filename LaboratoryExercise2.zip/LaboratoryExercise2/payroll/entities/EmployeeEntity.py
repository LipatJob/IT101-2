class EmployeeEntity:
    def __init__(self, employeeNumber = "",lastName = "",firstName = "",department = "",ratePerHour = 0):
        self.employeeNumber = employeeNumber
        self.lastName = lastName
        self.firstName = firstName
        self.department = department
        self.ratePerHour = ratePerHour