class PayrollRecordEntity:
    def __init__(self, employee = None, month = 0, daysWorked = 0):
        self.employee = employee
        self.month = month
        self.daysWorked = daysWorked
    
    