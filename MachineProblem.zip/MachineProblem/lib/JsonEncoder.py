import json
class JsonEncoder:
    """ Json Facade for Encoder type """
    def encode(self, data):
        return json.dumps(data)