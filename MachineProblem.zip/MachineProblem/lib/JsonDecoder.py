import json
class JsonDecoder:
    """ Json Facade for Decoder type """
    def decode(self, data):
        return json.loads(data)